<?php
/**
 * Template Name: Listing Archive
 *
 * @package Listify
 */

locate_template( array( 'archive-job_listing.php' ), true );