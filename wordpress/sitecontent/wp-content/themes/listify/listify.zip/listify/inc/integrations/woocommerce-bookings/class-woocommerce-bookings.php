<?php
/**
 * WooCommerce - Bookings 
 */

class Listify_WooCommerce_Bookings extends listify_Integration {

	public function integration() {
		return 'woocommerce-bookings';
	}

	public function __construct() {
		if ( ! class_exists( 'WP_Job_Manager_Products' ) ) {
			return;
		}

		$this->includes = array(

		);

		parent::__construct();
	}

	public function setup_actions() {
		add_action( 'widgets_init', array( $this, 'widgets_init' ) );

		$wpjmp = WPJMP();

		remove_action( 'single_job_listing_end', array( $wpjmp->products, 'listing_display_products' ) );
	}

	public function widgets_init() {
		$widgets = array(
			'job_listing-bookings.php'
		);

		foreach ( $widgets as $widget ) {
			include_once( listify_Integration::get_dir() . 'widgets/class-widget-' . $widget );
		}

		register_widget( 'Listify_Widget_Listing_Bookings' );
	}
}

$GLOBALS[ 'listify_woocommerce_bookings' ] = new Listify_WooCommerce_Bookings();
